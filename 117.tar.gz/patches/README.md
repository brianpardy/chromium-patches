# chromium-patches
Patches needed to build Chromium with GCC and/or libstdc++.
